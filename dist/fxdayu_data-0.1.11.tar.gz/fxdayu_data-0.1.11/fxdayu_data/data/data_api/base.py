# encoding: utf-8


class BasicConfig(object):

    def set(self, *args, **kwargs):
        pass

    def get(self, *args, **kwargs):
        pass


