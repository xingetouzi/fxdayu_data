# encoding:utf-8
from datetime import datetime
from pymongo.mongo_client import database
import pandas as pd
import pymongo


class DataHandler(object):

    def write(self, *args, **kwargs):
        pass

    def read(self, *args, **kwargs):
        pass

    def inplace(self, *args, **kwargs):
        pass

    def update(self, *args, **kwargs):
        pass

    def delete(self, *args, **kwargs):
        pass

    def table_names(self, *args, **kwargs):
        pass

