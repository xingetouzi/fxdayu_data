from datetime import datetime

from fxdayu_data.data.handler.mongo_handler import MongoHandler
from fxdayu_data.data.handler.redis_handler import RedisHandler


CANDLE_FIELDS = ['datetime', 'open', 'high', 'close', 'low', 'volume']


class ActiveData(object):

    def __init__(self, cache=None, external=None):
        if isinstance(cache, dict):
            self.cache = RedisHandler(**cache)
        elif isinstance(cache, RedisHandler):
            self.cache = cache
        else:
            self.cache = RedisHandler()

        if isinstance(external, dict):
            self.external = MongoHandler(**external)
        elif isinstance(external, MongoHandler):
            self.external = external
        else:
            self.external = MongoHandler()

        self.today = datetime.today().replace(minute=0, hour=0, second=0, microsecond=0)

    def only_cache(self, start, end, length):
        if start:
            if start < self.today:
                return False
            else:
                return True

        if end:
            if end < self.today:
                return False
            else:
                return True
        else:
            return True





